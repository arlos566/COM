
player_manager.AddValidModel( "MTF - NU7", "models/nostras/diehills/nu7.mdl" )
list.Set( "PlayerOptionsModel", "MTF - NU7", "models/nostras/diehills/nu7.mdl" )
player_manager.AddValidHands( "MTF - NU7", "models/ninja/mw3/delta/delta_force_arms.mdl", 0, "00000000" )

